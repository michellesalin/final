import TodoMain from './components/TodoMain'
const App = () => { 
  return (
    <div>
        <TodoMain />
    </div>
  );
}

export default App;
