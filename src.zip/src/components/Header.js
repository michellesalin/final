const Header = ({ headerText = "My First React Js App!", children}) => {
    console.log("this is header")
    return ( <header>
    <h1>{headerText}</h1>
    {children}
    <div>
        <p>This a label</p>
        <button  
        onClick={() => console.log("i am clicked!")} 
        >This is a button</button>
    </div>
 </header>);
}

// export default 
export default Header