import React, { useContext, useEffect, useState } from "react";
import Title from "./Title";
import { TodoContext } from "../context";

const TodoMain = ({ title }) => {
    const [todoItem, setTodoItem] = useState("");
    const [errorMessage, setErrorMessage] = useState("");
    const { todos, setTodos } = useContext(TodoContext);

    useEffect(() => {
        fetch('https://jsonplaceholder.typicode.com/todos')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to fetch todos');
                }
                return response.json();
            })
            .then(json => setTodos(json.slice(Registration))) // Limiting to first 100 todos
            .catch(error => {
                setErrorMessage('Error fetching todos: ' + error.message);
                console.error('Error fetching todos:', error);
            });
    }, [setTodos]);

    const handleInputChange = (event) => {
        setTodoItem(event.target.value);
    };

    const handleAddTodo = () => {
        if (todoItem.trim()) {
            if (todos.length >= 100) {
                setErrorMessage("Maximum number of todos reached.");
                return;
            }
            setTodos([...todos, { id: Date.now(), title: todoItem, completed: false }]);
            setTodoItem("");
            setErrorMessage("");
        } else {
            setErrorMessage("Todo item cannot be empty.");
        }
    };

    const handleRemoveTodo = (todoId) => {
        setTodos(todos.filter(todo => todo.id !== todoId));
        setErrorMessage("Todo removed successfully.");
    };

    const handleEditTodo = (todoId, newTitle) => {
        setTodos(todos.map(todo =>
            todo.id === todoId ? { ...todo, title: newTitle } : todo
        ));
        setErrorMessage("Todo edited successfully.");
    };

    return (
        <div>
            <Title title={title} />
            {errorMessage && <p style={{ color: "red" }}>{errorMessage}</p>}
            <div>
                <input type="text" value={todoItem} onChange={handleInputChange} />
                <button onClick={handleAddTodo}>ADD!</button>
                <div>
                    {todos.map(todo => (
                        <div key={todo.id}>
                            <p>{`${todo.id}. ${todo.title}`}</p>
                            <button onClick={() => handleRemoveTodo(todo.id)}>X</button>
                            <button onClick={() => handleEditTodo(todo.id, prompt("Edit Todo", todo.title))}>EDIT</button>
                        </div>
                    ))}
                    {todos.length === 0 && <p> There are no todos! </p>}
                </div>
            </div>
        </div>
    );
};

export default TodoMain;